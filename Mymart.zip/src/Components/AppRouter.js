import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";


const AppRouter = () => {
  return (
    <div>
          <BrowserRouter>
              <Routes>
                 
          </Routes>
          </BrowserRouter>
    </div>
  )
}

export default AppRouter
